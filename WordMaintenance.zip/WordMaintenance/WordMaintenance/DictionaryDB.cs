﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordMaintenance
{
    public static class DictionaryDB
    {
        // The AddWord method adds a new row to the Words tbale.
        // This method receives a Word object that contains the data for the new row.
        // Then a command object that contains an Insert statement with 
        // a parameter for each column in the row is created.
        // After the command is created, the parameters are created 
        // and added to the Parameters collection of the command.
       
        public static int AddWord(Word word)
        {
            SqlConnection connection = WordDB.GetConnection();
            string insertStatement =
                "INSERT INTO [dbo].[Words] " +
                "([WordName],[WordImage],[WordDescription]) " +
                "VALUES (@WordName,@WordImage,@WordDescription) ";
            SqlCommand insertCommand = new SqlCommand(insertStatement, connection);
            insertCommand.Parameters.AddWithValue("@WordName", word.WordName);
            insertCommand.Parameters.AddWithValue("@WordImage", word.WordImage);
            insertCommand.Parameters.AddWithValue("@WordDescription", word.WordDescription);
            try
            {
                connection.Open();
                insertCommand.ExecuteNonQuery();
                string selectStatement =
                    "SELECT IDENT_CURRENT('Words') FROM dbo.Words";
                SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
                int wordID = Convert.ToInt32(selectCommand.ExecuteScalar());
                
                return wordID;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }  
        }// end AddWord

        // The DeleteWord method receives Word object as an argument.
        // This methods implements a concurrency checking.
        // It specifies the values of each of the word columns in the 
        // where clause of the Delete statement
        // Then, if the delete operation is unsuccessful due to a concurrency error, 
        // the method returns false. Otherwise, it returns true.
        public static bool DeleteWord(Word word)
        {
            string deleteStatement = 
                "DELETE FROM dbo.Words " +
                "WHERE WordID = @WordID " +
                "AND WordName = @WordName " +
                "AND WordImage = @WordImage " +
                "AND WordDescription = @WordDescription ";
            using (SqlConnection connection = WordDB.GetConnection())
            {
                using (SqlCommand deleteCommand = new SqlCommand(deleteStatement, connection))
                {
                    deleteCommand.Parameters.AddWithValue("@WordID", word.WordID);
                    deleteCommand.Parameters.AddWithValue("@WordName", word.WordName);
                    deleteCommand.Parameters.AddWithValue("@WordImage", word.WordImage);
                    deleteCommand.Parameters.AddWithValue("@WordDescription", word.WordDescription);
                    try
                    {
                        connection.Open();
                        int count = deleteCommand.ExecuteNonQuery();
                        if (count > 0)
                            return true;
                        else
                            return false;
                    }
                    catch (SqlException ex)
                    {
                        throw ex;
                    } // end try-catch
                    
                } // end deleteCommand
            }// end connection
            
        } // end DeleteWord

        // The UpdateWord method receives two arguments: a Word object named oldWord 
        // that contains the original data for the word row to be updated, 
        // and another Word objects named newWord that supplies the updated values for the Word.
        // The properties of these objects are used to set the values of the parameters defined 
        // by the Update statement associated with the command object.
        public static bool UpdateWord(Word newWord, Word oldWord)
        {
            SqlConnection connection = WordDB.GetConnection();
            string updateStatement =
                "UPDATE dbo.Words " +
                "SET " +
                "[WordImage] = @NewWordImage ," +
                "[WordDescription] = @NewWordDescription " +
                "WHERE[WordID] = @oldWordID " +
                "AND [WordName] = @oldWordName " +
                "AND [WordImage] = @oldWordImage " +
                "AND [WordDescription] = @oldWordDescription";
            SqlCommand updateCommand = new SqlCommand(updateStatement, connection);
            updateCommand.Parameters.AddWithValue("@NewWordName", newWord.WordName);
            updateCommand.Parameters.AddWithValue("@NewWordImage", newWord.WordImage);
            updateCommand.Parameters.AddWithValue("@NewWordDescription", newWord.WordDescription);

            updateCommand.Parameters.AddWithValue("@oldWordID", oldWord.WordID);
            updateCommand.Parameters.AddWithValue("@oldWordName", oldWord.WordName);
            updateCommand.Parameters.AddWithValue("@oldWordImage",oldWord.WordImage);
            updateCommand.Parameters.AddWithValue("@oldWordDescription", oldWord.WordDescription);

            try
            {
                connection.Open();
                int count = updateCommand.ExecuteNonQuery();
                if (count > 0)
                    return true;
                else
                    return false;
            }
            catch(SqlException ex)
            {
                throw ex;

            }
            finally
            {
                connection.Close();
            }
        } // end UpdateWord
        

        // This method populates the DictionaryOfWord objects
        public static Dictionary<string, Word> PopulateDictionaryOfWord()
        {
            string selectStatement =
               "SELECT [WordID], " +
               "[WordName], " +
               "[WordImage]," +
               "[WordDescription] " +
               "FROM [dbo].[Words]";
           
            Dictionary<string, Word> wordDictionary = new Dictionary<string, Word>();
            if (wordDictionary.Count > 0)
                wordDictionary.Clear();
            SqlConnection connection = WordDB.GetConnection();
            SqlCommand selectCommand = new SqlCommand(selectStatement, connection);
            try
            {
                connection.Open();
                SqlDataReader reader = selectCommand.ExecuteReader(CommandBehavior.CloseConnection);

                while (reader.Read())
                {
                    
                   wordDictionary.Add(
                                        reader["WordName"].ToString()
                                        , new Word(
                                                    Convert.ToInt32(reader["WordID"].ToString())
                                                    , reader["WordName"].ToString()
                                                    , reader["WordImage"].ToString()
                                                    , reader["WordDescription"].ToString()
                                                   )
                                       );
                }

                return wordDictionary;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }

        }// end PopulateDictionaryOfWord


        // This method truncates the data from a table
        public static void TruncateTable()
        {
            string truncateStatement =
                "TRUNCATE TABLE dbo.Words";
                using (SqlConnection connection = WordDB.GetConnection())
                {
                    using (SqlCommand truncateCommand = new SqlCommand(truncateStatement, connection))
                    {
                        try
                        {
                            connection.Open();
                            truncateCommand.ExecuteNonQuery();
                        }
                        catch (SqlException ex)
                        {
                            throw ex;
                        }
                    } // end truncateCommand
                } // end connection
        } // end TruncateTable
    } // end DictionaryDB
}
