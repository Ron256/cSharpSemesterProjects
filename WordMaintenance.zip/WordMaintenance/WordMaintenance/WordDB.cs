﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordMaintenance
{
    public static class WordDB
    {
        // This static method sets the conection string of the SQL Server Express database.
        public static SqlConnection GetConnection()
        {
            string connection = "Data Source=(LocalDB)\\MSSQLLocalDB;" + 
                "AttachDbFilename=|DataDirectory|\\CapStoneDatabase.mdf;" + 
                "Integrated Security=True;Connect Timeout=30";
            SqlConnection sqlConnection = new SqlConnection(connection);
            return sqlConnection;
        } // end GetConnection
    }
}
