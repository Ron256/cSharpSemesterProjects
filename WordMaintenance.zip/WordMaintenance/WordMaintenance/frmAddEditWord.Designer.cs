﻿namespace WordMaintenance
{
    partial class frmAddEditWord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWordAddEdit = new System.Windows.Forms.Label();
            this.txtAddEditWord = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtImageName = new System.Windows.Forms.TextBox();
            this.txtImageDescription = new System.Windows.Forms.TextBox();
            this.btnAddEdit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblWordAddEdit
            // 
            this.lblWordAddEdit.AutoSize = true;
            this.lblWordAddEdit.Location = new System.Drawing.Point(13, 13);
            this.lblWordAddEdit.Name = "lblWordAddEdit";
            this.lblWordAddEdit.Size = new System.Drawing.Size(91, 17);
            this.lblWordAddEdit.TabIndex = 0;
            this.lblWordAddEdit.Text = "Word to Add:";
            // 
            // txtAddEditWord
            // 
            this.txtAddEditWord.Location = new System.Drawing.Point(16, 34);
            this.txtAddEditWord.Name = "txtAddEditWord";
            this.txtAddEditWord.Size = new System.Drawing.Size(437, 22);
            this.txtAddEditWord.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Image Name:";
            // 
            // txtImageName
            // 
            this.txtImageName.Location = new System.Drawing.Point(16, 95);
            this.txtImageName.Name = "txtImageName";
            this.txtImageName.Size = new System.Drawing.Size(437, 22);
            this.txtImageName.TabIndex = 3;
            // 
            // txtImageDescription
            // 
            this.txtImageDescription.Location = new System.Drawing.Point(16, 141);
            this.txtImageDescription.Multiline = true;
            this.txtImageDescription.Name = "txtImageDescription";
            this.txtImageDescription.Size = new System.Drawing.Size(518, 205);
            this.txtImageDescription.TabIndex = 4;
            // 
            // btnAddEdit
            // 
            this.btnAddEdit.Location = new System.Drawing.Point(16, 366);
            this.btnAddEdit.Name = "btnAddEdit";
            this.btnAddEdit.Size = new System.Drawing.Size(518, 31);
            this.btnAddEdit.TabIndex = 5;
            this.btnAddEdit.Text = "Add Word";
            this.btnAddEdit.UseVisualStyleBackColor = true;
            this.btnAddEdit.Click += new System.EventHandler(this.btnAddEdit_Click);
            // 
            // frmAddEditWord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 402);
            this.Controls.Add(this.btnAddEdit);
            this.Controls.Add(this.txtImageDescription);
            this.Controls.Add(this.txtImageName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtAddEditWord);
            this.Controls.Add(this.lblWordAddEdit);
            this.Name = "frmAddEditWord";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAddEditWord";
            this.Load += new System.EventHandler(this.frmAddEditWord_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWordAddEdit;
        private System.Windows.Forms.TextBox txtAddEditWord;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtImageName;
        private System.Windows.Forms.TextBox txtImageDescription;
        private System.Windows.Forms.Button btnAddEdit;
    }
}