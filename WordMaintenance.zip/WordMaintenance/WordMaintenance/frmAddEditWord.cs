﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordMaintenance
{
    public partial class frmAddEditWord : Form
    {
        public bool addWord;
        public Word word;
        public Dictionary<string, Word> dictionaryOfWordsAdded;
        public string selectedItemString;
        public string message = null;
        

        public frmAddEditWord()
        {
            InitializeComponent();
        }

        private void frmAddEditWord_Load(object sender, EventArgs e)
        {
            if(addWord)
            {
                this.Text = "Add a Word";
            }
            else
            {
                this.Text = "Edit a Word";
                this.lblWordAddEdit.Text = "Word to Edit:";
                this.btnAddEdit.Text = "Edit Word:";
                this.DisplayWord();
            }
        } // end frmAddEditWord_Load

        // The display method searches a list Of Word objects for the 
        // selected word in the listbox that it intends to edit.
        private void DisplayWord()
        {
            Word wordObj = null;
            if (dictionaryOfWordsAdded.TryGetValue(selectedItemString, out wordObj))
            {
                txtAddEditWord.Text = wordObj.WordName.ToString();
                txtImageName.Text = wordObj.WordImage.ToString();
                txtImageDescription.Text = wordObj.WordDescription.ToString();
                txtAddEditWord.Enabled = false;

            }
        } // end DisplayWord

        // If the user Add or edit button, the Click event handler for this button starts 
        // by calling the IsValidData method.
        // This method calls the IsPresent method of the Validator class 
        // for each text box to determine it conatins data.
        // if the data is valid, the event handler continues 
        // by checking whether a word is being added  or modified.
        // If a word is being added, the word field is set to a new Word object and the PutWordData method is called.
        // This method sets the properties of the Word object to the values that the user entered on the form.
        private void btnAddEdit_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
                if (addWord)
                {
                    word = new Word();
                    this.PutWordData(word);
                    try
                    {
                        // Execute the AddWord method of the DictionaryDB class and assigns new the Word ID 
                        // that is returned to the WordID property of the Word object
                        word.WordID = DictionaryDB.AddWord(word);
                        // If no SQLServer error occurs, the DialogResult property of the form is set to DialogResult.OK
                        // which causes the form to be closed and control to be returned to the Word Maintenance Form.
                        // Otherwise, the exception is caught and an error message is caught.
                        
                       
                        this.DialogResult = DialogResult.OK;
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, ex.GetType().ToString());
                    }
                  
                }
                else
                {
                    // if the customer is being modified, the event Handler starts by creating a new Word object
                    // and storing it in the newWord Variable.
                    // Then it the WordID property of the object to the WordID property of the current Word object

                    Word newWord = new Word();

                    // Search the data DicionaryOfWord for a given Word 
                    // and assign the WordId of that Word object to the newWord object
                    // also make the word object of the selectedItem to reference the word object

                    Word dictWord = null;
                    if (dictionaryOfWordsAdded.TryGetValue(selectedItemString, out dictWord))
                    {
                        newWord.WordID = dictWord.WordID;
                        word = dictWord;
                    }

                    // Next it calls the UpdateWord method of the DictionaryDB class and passes it both the old and new Word objects.
                    // if concurrency error occurs, a value of false is returned.
                    // In that case an error message is displayed and the DialogResult property of the form is set to DialogResult.Retry.
                    // Otherwise a new Word object is assigned to the original Word object 
                    // and DialogResult property is set to DialogResult.OK; in either case the form is closed
                    this.PutWordData(newWord);
                    try
                    {
                        
                        if(!DictionaryDB.UpdateWord(newWord, word))
                        {
                            MessageBox.Show("Another user has updated or " + 
                                "deleted that customer.", "Database Error");
                            this.DialogResult = DialogResult.Retry;
                        }
                        else
                        {
                            word = newWord;
                            this.DialogResult = DialogResult.OK;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, ex.GetType().ToString());
                    }
                }
            }
        }

        private bool IsValidData()
        {
            return
                Validator.IsPresent(txtAddEditWord) &&
                Validator.IsPresent(txtImageName) &&
                Validator.IsPresent(txtImageDescription);
        } // end IsValidData

        private void PutWordData(Word word)
        {
            word.WordName = txtAddEditWord.Text.Trim();  
            word.WordImage = txtImageName.Text.Trim();
            word.WordDescription = txtImageDescription.Text.Trim();
        } // end PutWordData

    } // end frmAddEditWord
} // end WordMaintenance
