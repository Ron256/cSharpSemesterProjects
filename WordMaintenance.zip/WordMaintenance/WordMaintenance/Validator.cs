﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordMaintenance
{
    public static class Validator
    {
        private static string title = "Entry Error";
        private const string errorMessage = "None of the textboxes can be left blank";

        public static string Title
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
            }
        } // end Title

        // This method checks to see whether the user has entered any value in 
        // a textbox
        public static bool IsPresent(TextBox textBox)
        {
            if(textBox.Text == "")
            {
                MessageBox.Show(errorMessage, Title, MessageBoxButtons.OK,MessageBoxIcon.Warning);
                textBox.Focus();
                return false;
            }
            return true;
        } // end IsPresent
    }
}
