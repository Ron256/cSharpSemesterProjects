﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordMaintenance
{
    public partial class frmWordMaintenance : Form
    {
        private Word word;
        private string filePath = @Directory.GetCurrentDirectory() + "\\" + "images" + "\\";
        private List<string> fileNameList = new List<string>();
        private string[] fileName = null;
       
        Dictionary<string, Word> populatedDictionaryOfWords;

       
        public frmWordMaintenance()
        {
            InitializeComponent();
            btnDeleteWord.Enabled = false;
            btnEditWord.Enabled = false;
            DictionaryDB.TruncateTable();
            LoadImagesInList();
            
        }

        // This method uses the static method GetFiles of the Directory class to 
        // return a list of files to the array of string
        // Uses a for loop to process each file name image as it adds them to the memory 
        // using the List of Strings data structure
        private void LoadImagesInList()
        {
            string fileImagePath = filePath + "\\" + "images" + "\\";
            fileName = Directory.GetFiles(filePath);
            for (int i = 0; i < fileName.Length; i++)
            {
                fileNameList.Add(fileName[i]);
            }
            fileNameList.Sort();
        }// end LoadImagesInList

        private void wordListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string wordListBoxStr = wordListBox.SelectedItem.ToString();
                if (wordListBoxStr == "dog")
                {
                    ImageSearch(wordListBoxStr);
                    SearchCorrespondingDesc(populatedDictionaryOfWords);
                }
                else if (wordListBoxStr == "atom")
                {
                    ImageSearch(wordListBoxStr);
                    SearchCorrespondingDesc(populatedDictionaryOfWords);
                }
                else if (wordListBoxStr == "fire")
                {
                    ImageSearch(wordListBoxStr);
                    SearchCorrespondingDesc(populatedDictionaryOfWords);
                }
                else if (wordListBoxStr == "sandals")
                {
                    ImageSearch(wordListBoxStr);
                    SearchCorrespondingDesc(populatedDictionaryOfWords);
                }
            }
            catch (Exception ex)
            {
                
                MessageBox.Show("User must select at least one item before proceeding", ex.GetType().ToString());
            } // end try-catch
            

        } // end WordListBox_SelectedIndexChanged

        // The ImageSearch Method is declared with two parameters which it uses to search for the corresponding image path
        // using a BinarySearch.
        // It uses this path for the Image to display in the PictureBox.
        private void ImageSearch(string wordListBoxStr)
        {
            string fileName = wordListBoxStr + ".png";
            Word dictWord = null;
            if (populatedDictionaryOfWords.TryGetValue(wordListBoxStr, out dictWord))
            {
                if (dictWord.WordName == wordListBoxStr && dictWord.WordImage == fileName)
                {
                    int counter = fileNameList.BinarySearch(filePath + wordListBoxStr + ".png");
                    picBoxName.ImageLocation = fileNameList[counter];
                }
                else
                {
                    MessageBox.Show("Something went wrong" 
                        + "\n"
                        + "Please edit the name of the Image"
                        , "Image Error");
                    btnEditWord.Focus();
                } // end if-else
            } //  end if 
        }// end ImageSearch

        // When the user clicks the Add Word button,  first it sets th public addWord field of the form to true so the form will know that a new word is being added
        // if the word is added successfully, the new word is retrieved from the Add/Edit Word form The n data for the few word is displayed on the form
        // and the modify and delete buttons are enabled.
        private void btnAddWord_Click(object sender, EventArgs e)
        {
            frmAddEditWord addEdit = new frmAddEditWord();
            addEdit.addWord = true;
            DialogResult result = addEdit.ShowDialog();
            if (result == DialogResult.OK)
            {
                word = addEdit.word;

                
                if (DictionaryDB.PopulateDictionaryOfWord().Count > 0 )
                {
                    
                    populatedDictionaryOfWords = DictionaryDB.PopulateDictionaryOfWord();
                }
                toolStripStatuslbl.Text = "Data saved successfully!";
                statusStripControl.Refresh();
                this.DisplayWord();
            }
        }// end btnAddWord_Click

        private void DisplayWord()
        {
            if(wordListBox.Items.Count > 0)
            {
                wordListBox.Items.Clear();
            }
            
            LoadListBox(populatedDictionaryOfWords);
            btnEditWord.Enabled = true;
            btnDeleteWord.Enabled = true;
        } //end DisplayWord


        private void btnEditWord_Click(object sender, EventArgs e)
        {
            try
            {
                string wordListBoxItemSelected = wordListBox.SelectedItem.ToString();
                frmAddEditWord editWordForm = new frmAddEditWord();
                editWordForm.addWord = false;
                editWordForm.selectedItemString = wordListBoxItemSelected;
                editWordForm.dictionaryOfWordsAdded = populatedDictionaryOfWords;
                DialogResult result = editWordForm.ShowDialog();
                if (result == DialogResult.OK)
                {
                    
                    if (DictionaryDB.PopulateDictionaryOfWord().Count > 0)
                    {

                        populatedDictionaryOfWords = DictionaryDB.PopulateDictionaryOfWord();
                    }
                    toolStripStatuslbl.Text = "Data was edited!";
                    statusStripControl.Refresh();
                    this.DisplayWord();
                }
                else if (result == DialogResult.Retry)
                {
                    
                    if (word != null)
                        this.DisplayWord();
                }
            }
            catch (Exception ex)
            {
                string message = "User must select one item in the ListBox " + "\n" +
                                "before making any changes." + "\n" + "Details: " + ex.Message;
                MessageBox.Show(message, "Exception"
                                , MessageBoxButtons.OK
                                ,MessageBoxIcon.Warning);
            }

            
        } // end btnEditWord_Click



        // The LoadListBox method accepts populatedDictionaryOfWords as a paramters which it loops 
        // through using the foreach loop as it adds the WordName property to the ListBox control.
        private void LoadListBox(Dictionary<string, Word> populatedDictionaryOfWords)
        {
            foreach (KeyValuePair<string, Word> keyValue in populatedDictionaryOfWords)
            {
                if (keyValue.Key == "dog")
                {
                    wordListBox.Items.Add(keyValue.Value.WordName);
                    picBoxName.Image = null;
                    txtDescription.Text = "";
                }
                else if (keyValue.Key == "fire")
                {
                    wordListBox.Items.Add(keyValue.Value.WordName);
                    picBoxName.Image = null;
                    txtDescription.Text = "";
                }
                else if (keyValue.Key == "atom")
                {
                    wordListBox.Items.Add(keyValue.Value.WordName);
                    picBoxName.Image = null;
                    txtDescription.Text = "";
                }
                else if (keyValue.Key == "sandals")
                {
                    wordListBox.Items.Add(keyValue.Value.WordName);
                    picBoxName.Image = null;
                    txtDescription.Text = "";
                }
            } // end foreach

            if (wordListBox.Items.Count == 0)
            {
                picBoxName.Image = null;
                txtDescription.Text = "";
            }

        } // end LoadListBox

        // The SearchCorrespongingDesc method searches the Dictionary of Word object 
        // for a corresponding description of any selected Word.
        // it uses the TryGetValue method of the Dictionary object to peform the search.
        private void SearchCorrespondingDesc(Dictionary<string, Word> populatedDictionaryOfWords)
        {
            string wordListBoxStr = wordListBox.SelectedItem.ToString();
            Word wordValue = null;
            if (populatedDictionaryOfWords.TryGetValue(wordListBoxStr, out wordValue))
            {
                txtDescription.Text = wordValue.WordDescription.ToString();
            }
        }// end ProcessIceCreamOrderList

        private void btnDeleteWord_Click(object sender, EventArgs e)
        {
            try
            {
                Word toBeDeleted = null;
                if (populatedDictionaryOfWords.TryGetValue(wordListBox.SelectedItem.ToString(), out toBeDeleted))
                {
                    word = toBeDeleted;
                }
                DialogResult result = MessageBox.Show("Delete " + wordListBox.SelectedItem.ToString() + "?",
                    "Confirm Delete"
                    , MessageBoxButtons.YesNo
                    , MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    try
                    {
                        if (!DictionaryDB.DeleteWord(word))
                        {
                            MessageBox.Show("Another user has updated or deleted " +
                                "that word.", "Database Error");
                        }
                        else
                        {
                            if (DictionaryDB.PopulateDictionaryOfWord().Count >= 0)
                            {
                                populatedDictionaryOfWords.Clear();
                                populatedDictionaryOfWords = DictionaryDB.PopulateDictionaryOfWord();
                            }
                            toolStripStatuslbl.Text = "Data was deleted!";
                            statusStripControl.Refresh();
                            this.DisplayWord();
                        } // end if-else


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, ex.GetType().ToString());
                    }

                }
            }

            catch (Exception ex)
            {
                string message = "User must select one item from the ListBox above " + "\n" +
                                "before either editing or deleting the data." + "\n" +
                                "Details: " + ex.Message;
                MessageBox.Show(message, "Exception"
                                , MessageBoxButtons.OK
                                , MessageBoxIcon.Warning);
            } // end try-catch
            
        } // end btnDeleteWord_Click
    }
}
