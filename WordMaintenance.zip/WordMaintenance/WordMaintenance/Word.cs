﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordMaintenance
{
    public class Word
    {
        private int wordID;
        private string wordName;
        private string wordImage;
        private string wordDescription;
        

        public Word()
        {
        }
        
        public Word(int wordID, string wordName, string wordImage, string wordDescription)
        {
            this.wordID = wordID;
            this.WordName = wordName;
            this.WordImage = wordImage;
            this.WordDescription = wordDescription;
        }

        public int WordID
        {
            get
            {
                return wordID;
            }
            set
            {
                wordID = value;
            }
        }
        public string WordName
        {
            get
                {
                return wordName;
            }
            set
                {
                wordName = value;
            }
        } // end WordName

        public string WordImage
        {
            get
            {
                return wordImage;
            }
            set
            {
                wordImage = value;
            }
        } // end WordImage

        public string WordDescription
        {
            get
            {
                return wordDescription;
            }
            set
            {
                wordDescription = value;
            }
        }// end WordDescription
    }
}
