﻿namespace WordMaintenance
{
    partial class frmWordMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wordListBox = new System.Windows.Forms.ListBox();
            this.picBoxName = new System.Windows.Forms.PictureBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.btnAddWord = new System.Windows.Forms.Button();
            this.btnDeleteWord = new System.Windows.Forms.Button();
            this.btnEditWord = new System.Windows.Forms.Button();
            this.statusStripControl = new System.Windows.Forms.StatusStrip();
            this.toolStripStatuslbl = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxName)).BeginInit();
            this.statusStripControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // wordListBox
            // 
            this.wordListBox.FormattingEnabled = true;
            this.wordListBox.ItemHeight = 20;
            this.wordListBox.Location = new System.Drawing.Point(14, 15);
            this.wordListBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.wordListBox.Name = "wordListBox";
            this.wordListBox.Size = new System.Drawing.Size(226, 444);
            this.wordListBox.TabIndex = 0;
            this.wordListBox.SelectedIndexChanged += new System.EventHandler(this.wordListBox_SelectedIndexChanged);
            // 
            // picBoxName
            // 
            this.picBoxName.Location = new System.Drawing.Point(246, 15);
            this.picBoxName.Margin = new System.Windows.Forms.Padding(3, 12, 3, 12);
            this.picBoxName.Name = "picBoxName";
            this.picBoxName.Size = new System.Drawing.Size(313, 445);
            this.picBoxName.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBoxName.TabIndex = 1;
            this.picBoxName.TabStop = false;
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(567, 16);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDescription.Size = new System.Drawing.Size(504, 443);
            this.txtDescription.TabIndex = 2;
            // 
            // btnAddWord
            // 
            this.btnAddWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddWord.Location = new System.Drawing.Point(15, 469);
            this.btnAddWord.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAddWord.Name = "btnAddWord";
            this.btnAddWord.Size = new System.Drawing.Size(225, 29);
            this.btnAddWord.TabIndex = 3;
            this.btnAddWord.Text = "Add Word";
            this.btnAddWord.UseVisualStyleBackColor = true;
            this.btnAddWord.Click += new System.EventHandler(this.btnAddWord_Click);
            // 
            // btnDeleteWord
            // 
            this.btnDeleteWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteWord.Location = new System.Drawing.Point(15, 506);
            this.btnDeleteWord.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDeleteWord.Name = "btnDeleteWord";
            this.btnDeleteWord.Size = new System.Drawing.Size(225, 29);
            this.btnDeleteWord.TabIndex = 4;
            this.btnDeleteWord.Text = "Delete Word";
            this.btnDeleteWord.UseVisualStyleBackColor = true;
            this.btnDeleteWord.Click += new System.EventHandler(this.btnDeleteWord_Click);
            // 
            // btnEditWord
            // 
            this.btnEditWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditWord.Location = new System.Drawing.Point(15, 544);
            this.btnEditWord.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnEditWord.Name = "btnEditWord";
            this.btnEditWord.Size = new System.Drawing.Size(225, 29);
            this.btnEditWord.TabIndex = 5;
            this.btnEditWord.Text = "Edit Word";
            this.btnEditWord.UseVisualStyleBackColor = true;
            this.btnEditWord.Click += new System.EventHandler(this.btnEditWord_Click);
            // 
            // statusStripControl
            // 
            this.statusStripControl.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStripControl.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatuslbl});
            this.statusStripControl.Location = new System.Drawing.Point(0, 620);
            this.statusStripControl.Name = "statusStripControl";
            this.statusStripControl.Padding = new System.Windows.Forms.Padding(1, 0, 16, 0);
            this.statusStripControl.Size = new System.Drawing.Size(1084, 22);
            this.statusStripControl.TabIndex = 6;
            this.statusStripControl.Text = "statusStrip1";
            // 
            // toolStripStatuslbl
            // 
            this.toolStripStatuslbl.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripStatuslbl.Name = "toolStripStatuslbl";
            this.toolStripStatuslbl.Size = new System.Drawing.Size(0, 17);
            // 
            // frmWordMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1084, 642);
            this.Controls.Add(this.statusStripControl);
            this.Controls.Add(this.btnEditWord);
            this.Controls.Add(this.btnDeleteWord);
            this.Controls.Add(this.btnAddWord);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.picBoxName);
            this.Controls.Add(this.wordListBox);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmWordMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Personal Dictionary";
            ((System.ComponentModel.ISupportInitialize)(this.picBoxName)).EndInit();
            this.statusStripControl.ResumeLayout(false);
            this.statusStripControl.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox wordListBox;
        private System.Windows.Forms.PictureBox picBoxName;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Button btnAddWord;
        private System.Windows.Forms.Button btnDeleteWord;
        private System.Windows.Forms.Button btnEditWord;
        private System.Windows.Forms.StatusStrip statusStripControl;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatuslbl;
    }
}

