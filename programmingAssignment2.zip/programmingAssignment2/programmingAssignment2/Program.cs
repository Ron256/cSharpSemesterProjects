﻿
///<summary> The objective of this program is:
///<para> To obtain user input using TextBoxes </para>
///<para>To use the ListBox Control </para>
///<para>To create event handlers</para>
///<para>To use methods to functionally divide and conquer a larger problem</para>
///</summary>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace programmingAssignment2
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
