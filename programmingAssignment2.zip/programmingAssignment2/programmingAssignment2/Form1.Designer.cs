﻿namespace programmingAssignment2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.foodOrderListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtfoodOrderTextBox = new System.Windows.Forms.TextBox();
            this.btnAddToList = new System.Windows.Forms.Button();
            this.btnLoadOrderFromFile = new System.Windows.Forms.Button();
            this.btnSaveOrderToFile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // foodOrderListBox
            // 
            this.foodOrderListBox.FormattingEnabled = true;
            this.foodOrderListBox.ItemHeight = 20;
            this.foodOrderListBox.Location = new System.Drawing.Point(12, 60);
            this.foodOrderListBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.foodOrderListBox.Name = "foodOrderListBox";
            this.foodOrderListBox.Size = new System.Drawing.Size(343, 384);
            this.foodOrderListBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "Food Order:";
            // 
            // label2
            // 
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(378, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 36);
            this.label2.TabIndex = 2;
            this.label2.Text = "Food Order:";
            // 
            // txtfoodOrderTextBox
            // 
            this.txtfoodOrderTextBox.Location = new System.Drawing.Point(378, 60);
            this.txtfoodOrderTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtfoodOrderTextBox.Name = "txtfoodOrderTextBox";
            this.txtfoodOrderTextBox.Size = new System.Drawing.Size(282, 26);
            this.txtfoodOrderTextBox.TabIndex = 3;
            // 
            // btnAddToList
            // 
            this.btnAddToList.Location = new System.Drawing.Point(378, 100);
            this.btnAddToList.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAddToList.Name = "btnAddToList";
            this.btnAddToList.Size = new System.Drawing.Size(206, 35);
            this.btnAddToList.TabIndex = 4;
            this.btnAddToList.Text = "Add To List";
            this.btnAddToList.UseVisualStyleBackColor = true;
            this.btnAddToList.Click += new System.EventHandler(this.btnAddToList_Click);
            // 
            // btnLoadOrderFromFile
            // 
            this.btnLoadOrderFromFile.Location = new System.Drawing.Point(12, 457);
            this.btnLoadOrderFromFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLoadOrderFromFile.Name = "btnLoadOrderFromFile";
            this.btnLoadOrderFromFile.Size = new System.Drawing.Size(270, 46);
            this.btnLoadOrderFromFile.TabIndex = 5;
            this.btnLoadOrderFromFile.Text = "Load Order From File";
            this.btnLoadOrderFromFile.UseVisualStyleBackColor = true;
            this.btnLoadOrderFromFile.Click += new System.EventHandler(this.btnLoadOrderFromFile_Click);
            // 
            // btnSaveOrderToFile
            // 
            this.btnSaveOrderToFile.Location = new System.Drawing.Point(12, 507);
            this.btnSaveOrderToFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSaveOrderToFile.Name = "btnSaveOrderToFile";
            this.btnSaveOrderToFile.Size = new System.Drawing.Size(270, 51);
            this.btnSaveOrderToFile.TabIndex = 6;
            this.btnSaveOrderToFile.Text = "Save Order to File";
            this.btnSaveOrderToFile.UseVisualStyleBackColor = true;
            this.btnSaveOrderToFile.Click += new System.EventHandler(this.btnSaveOrderToFile_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 594);
            this.Controls.Add(this.btnSaveOrderToFile);
            this.Controls.Add(this.btnLoadOrderFromFile);
            this.Controls.Add(this.btnAddToList);
            this.Controls.Add(this.txtfoodOrderTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.foodOrderListBox);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "The Food Order App";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox foodOrderListBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtfoodOrderTextBox;
        private System.Windows.Forms.Button btnAddToList;
        private System.Windows.Forms.Button btnLoadOrderFromFile;
        private System.Windows.Forms.Button btnSaveOrderToFile;
    }
}

