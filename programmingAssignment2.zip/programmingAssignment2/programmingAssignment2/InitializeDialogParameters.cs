﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace programmingAssignment2
{
    // InitializeDialogParameters is a static class with two static methods
    // whose purpose is to initialize the members of OpenFileDialog and SaveFileDialog objects.
    static class InitializeDialogParameters
    {
        // The InitializeOpenFileDialog method Initializes the members of the OpenFileDialog object
        // It takes the object of the OpenFileDialog class as a parameter 
        // and returns the object of the OpenFileDialog.
        public static OpenFileDialog InitializeOpenFileDialog(OpenFileDialog readFileDialog)
        {
            readFileDialog.Filter = "order Files(*.order)|";
            readFileDialog.RestoreDirectory = true;
            readFileDialog.FileName = "*.order";
            readFileDialog.DefaultExt = "order";
            return readFileDialog;
        }//end InitializeOpenFileDialog

        // The InitializeSaveFileDialog method Initializes the members of the SaveFileDialog object
        // it takes the SaveFileDialog object as a parameter
        // and returns the object of the SaveFileDialog.
        public static SaveFileDialog InitializeSaveFileDialog(SaveFileDialog locateFileDialog)
        {
            locateFileDialog.Filter = "order Files(*.order)|";
            locateFileDialog.RestoreDirectory = true;
            locateFileDialog.FileName = "*.order";
            locateFileDialog.DefaultExt = "order";
            return locateFileDialog;
        }//end InitializeSaveFileDialo
    }//end class
}//end programmingAssignment2
