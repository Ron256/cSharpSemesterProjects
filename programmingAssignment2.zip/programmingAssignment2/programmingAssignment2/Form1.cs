﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace programmingAssignment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // This event handling method adds the data entered by the user into a textbox to the ListBox.
        // It also removes any extra delimited characters
        // It invokes a method which capitalizes the first letter of every name
        private void btnAddToList_Click(object sender, EventArgs e)
        {
            if(IsValid())
            {
                // trim off the white spaces and return a string array that contains the substrings 
                // in this instance that are delimited by a blank space
                string[] foodOrderTextArr = txtfoodOrderTextBox.Text.Trim().Split(' ');
                string messageText = "";
                string processedMenuItem = "";

                // Loop through the foodOrderTextArr array of Strings 
                // and where an empty string is found do nothing
                // otherwise concatenate the string objects of food order item names
                // and add it to the ListBox items collections
                foreach(string menuItem in foodOrderTextArr)
                {
                    if(menuItem == "")
                    { 
                    }
                    else
                    {
                        // menuItem string object is passed as argument to the CapitalizeName method 
                        // which converts the first letter of a String into upper case 
                        // and converts the rest of the characters of the String into lower case.
                        processedMenuItem = CapitalizeNames(menuItem);
                        messageText += " " + processedMenuItem.Trim();
                    }// end if-else  
                }// end foreach
                foodOrderListBox.Items.Add(messageText);
            }// end if-statement
            txtfoodOrderTextBox.Text = "";
            txtfoodOrderTextBox.Focus();
        }// end btnAddToList_Click

        // This method Capitalizes the first letter of a String 
        // and converts the rest of the characters of the String into lower case.
        // It takes the String to be converted with the first Character into an upper case letter 
        // and the rest of the string into lower case as a parameter
        // returns the Converted String
        private string CapitalizeNames(string textString)
        {
            string localTextString = textString.Trim();

            // Convert with the first Character of a String into an upper case letter 
            // and the rest of the string into lower case
            return localTextString.Substring(0, 1).ToUpper() + localTextString.Substring(1).ToLower();
        }//end capitalizeNames

        // The IsPresent method is data validation method which 
        // Checks whether the user entered data into a textbox.
        // it accepts text box control to be validated and the name of the textbox as parameters
        // the method returns true if the user has entered data into a textbox.
        private bool IsPresent(TextBox textbox, string name)
        {
            if(textbox.Text == "")
            {
                MessageBox.Show(name + " textbox "+ "can not be empty");
                textbox.Focus();
                return false;
            }
            return true; ;
        }// end IsPresent

        // The IsInt32 is a custom method that checks whether the user has entered a numerical value into a text box.
        // it accepts text box control to be validated and the name of the textbox as parameters.
        // It returns false if the string entered is not an integer.
        private bool IsInt32(TextBox textbox, string name)
        {
            int foodOrderName;
            if(Int32.TryParse(textbox.Text, out foodOrderName))
            {
                MessageBox.Show(name + " textbox can not be a number "+ "\n" +
                                "Please define a valid String literal.","Food Order textbox error!");
                textbox.Focus();
                return true;
            }
            return false;
        }// end IsInt32

        // The IsDecimal method is a custom method that checks whether the user has entered a decimal value into a text box.
        // it accepts text box control to be validated and the name of the textbox as parameters.
        // returns false if the string entered is not a decimal literal.
        private bool IsDecimal(TextBox textbox, string name)
        {
            decimal foodOrderNumber = 0m;
            if(Decimal.TryParse(textbox.Text, out foodOrderNumber))
            {
                MessageBox.Show(name + " textbox can not be a decimal point number" + "\n" +
                                "Please define a valid String literal.", "Food Order textbox error!");
                textbox.Focus();
                return true;
            }
            return false;
        }// end IsDecimal

        // Checks whether the user data into a text box is valid string 
        // by also double checking whether the data entered is neither an integer nor a decimal.
        // returns true if the data entered is valid string.</returns>
        private bool IsValid()
        {
            return IsPresent(txtfoodOrderTextBox, "Food Order") && (!IsInt32(txtfoodOrderTextBox, "Food Order")) && (!IsDecimal(txtfoodOrderTextBox, "Food Order"));
        }//end IsValid

        // This event handling method writes the food items from a Listbox to a file by using the SaveFileDialog  class 
        // which allows to specify a location to save the file to and 
        // it uses a StreamWriter class used to write a stram of characters to a file.
        private void btnSaveOrderToFile_Click(object sender, EventArgs e)
        {
            Stream fileStream = null;
            StreamWriter writerStream = null;
            //Create a SaveFileDialog object
            SaveFileDialog locateFileDialog = new SaveFileDialog();
            SaveFileDialog writeFileDialog = null;

            // Initialize the SaveFileDialog object members by passing the SaveFileDialog object
            // as an argument to the static method InitializeSaveFileDialog
            writeFileDialog = InitializeDialogParameters.InitializeSaveFileDialog(locateFileDialog);

            // call the dialog box by using ShowDialog method and save the current file.
            if (writeFileDialog.ShowDialog() == DialogResult.OK)
            {
                // open the file with read/write permission selected by the user
                // and set the value returned to the fileStream reference type of Stream class
                fileStream = locateFileDialog.OpenFile();

                // Pass the fileStream reference type to the StreamWriter construtor as an argument 
                // to create a StreamWriter object.
                writerStream = new StreamWriter(fileStream);

                // Loop through each item in the foodOrderListBox collection 
                // and write it to a file
                foreach (string foodOrder in foodOrderListBox.Items)
                {
                    writerStream.WriteLine(foodOrder);
                }
                writerStream.Close();
                fileStream.Close();
            }//end if
        }//end btnSaveOrderToFile_Click

        // This event handling methodLoads the food items from a file to the List box by using
        // the OpenFileDialog object to select an order file that gets loaded into a List of Strings
        // it uses a StreamReader class used to write a stream of characters to a file.
        private void btnLoadOrderFromFile_Click(object sender, EventArgs e)
        {
            Stream fileStream = null;
            StreamReader readerStream = null;

            // create a OpenFileDialog object
            OpenFileDialog readFileDialog = new OpenFileDialog();
            OpenFileDialog initializedReadFileDialog = null;

            // Initializes the OpenFileDialog object members by passing the OpenFileDialog object as an argument 
            // to the static method InitializeOpenFileDialog
            initializedReadFileDialog = InitializeDialogParameters.InitializeOpenFileDialog(readFileDialog);

            // create a list of string foodOrderList
            List<string> foodOrderList = new List<string>();

            // Clears the Collections (foodOrderList and fooOrderListBox) if it contains any food order items
            // Also clears the ListBox item Collections if it contains any items already added
            ClearCollectionComponents(foodOrderList, foodOrderListBox);
            if (initializedReadFileDialog.ShowDialog() == DialogResult.OK)
            {
                // open the file with read/write permission selected by the user
                // and set the value returned to the fileStream reference type of Stream class
                fileStream = readFileDialog.OpenFile();

                // Pass the fileStream reference type to the StreamReader construtor as an argument 
                // to create a StreamReader object.
                readerStream = new StreamReader(fileStream);

                // Pass the StreamReader object as a parameter when calling the ProcessFileRead method
                // to read a file and adds the rows read into a list of strings
                // this method returns the memory address of the List of strings which is set to
                // the list of srings, foodOrderList.
                foodOrderList = ProcessFileRead(readerStream);
            }
            //Adds food order items from a list of strings to the ListBox.
            AddFoodOrderItems(foodOrderList);
            fileStream.Close();
            readerStream.Close();
        }//end btnLoadOrderFromFile_Click

        // The ClearCollectionComponents method clears the List of Strings and ListBox object collections.
        // Pass The list of Strings to be cleared 
        // and the ListBox whose items are to be cleared as parameters to this method
        private void ClearCollectionComponents(List<string> foodOrderList, ListBox foodOrderListBox)
        {
            if (foodOrderList != null)
            {
                foodOrderList.Clear();
            }
            if (foodOrderListBox.Items.Count > 0)
            {
                foodOrderListBox.Items.Clear();
            }
        }//end ClearCollectionComponents

        // The AddFoodOrderItems method adds food order items from a list of strings to the ListBox.
        // Pass a list of Strings of food order items as a parameter
        private void AddFoodOrderItems(List<string> foodOrderList)
        {
            //loop through the a list of string of food order items
            // and add each item to the listbox 
            foreach (var food in foodOrderList)
            {
                foodOrderListBox.Items.Add(food);
            }
        }//end AddFoodOrderItems
        
        // The ProcessFileRead method reads a file and adds the rows read into a list of strings
        // Pass a Stream reader object as a parameter whose value is to be processed
        // uses the Peek method in a while loop to return the next available character.
        // It returns a list of Strings once a stream of text characters have been read.
        private List<string> ProcessFileRead(StreamReader readFileStream)
        {
            List<string> OrderList = new List<string>();
            while (readFileStream.Peek() != -1)
            {
                var orderRow = readFileStream.ReadLine();
                OrderList.Add(orderRow);
            } 
            return OrderList;
        }//end processFileRead
    }//end class Form1
}//end namespace programmingAssignment2
