﻿
/** Ronaldlee Ejalu
 * CIS 2757
 * Fall 2018 Prof Ken Sigler
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProject1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if(IsValid())
            {
                int numberOne = Convert.ToInt32(txtNumberOne.Text);
                int numberTwo = Convert.ToInt32(txtNumberTwo.Text);
                String strOperator = Convert.ToString(txtOperator.Text);
                int resultSet = 0;
                resultSet = EvaluateExpression(numberOne, numberTwo, strOperator, resultSet);
                if (resultSet == -2)
                {
                    lblOutput.Text = "Invalid Operator";
                }
                else if (resultSet == -1)
                {
                    lblOutput.Text = "Number can't be divided by 0";
                }
                else
                    lblOutput.Text = resultSet.ToString();
            }//end if
           
        }//end btnCalculate_Click

        private int EvaluateExpression(int numberOne, int numberTwo, string strOperator, int resultSet)
        {
            switch (strOperator)
            {
                case "+":
                    resultSet = numberOne + numberTwo;
                    //lblOutput.Text = resultSet.ToString();
                    break;
                case "-":
                    resultSet = numberOne - numberTwo;
                    break;
                case "*":
                    resultSet = numberOne * numberTwo;
                    break;
                case "/":
                    if (numberTwo == 0)
                    {
                        resultSet = -1;
                        //MessageBox.Show("numberTwo is 0");
                        break;
                    }
                    else
                    {
                        resultSet = numberOne / numberTwo;
                        break;
                    }

                default:
                    resultSet = -2;
                    break;

            }//end Switch
            return resultSet;
        }//end EvaluateExpression
        public bool IsPresent(TextBox textbox)
        {
            if(textbox.Text == "")
            {
                lblOutput.Text = "None of the text boxes are supposed to be empty!";
                textbox.Focus();
                return false;
            }
            return true;
        }//end IsPresent

        public bool IsInt32(TextBox textbox)
        {
            int temp;
            if(Int32.TryParse(textbox.Text, out temp))
            {
                return true;
            }
            else
            {
                MessageBox.Show("The value entered into any of the textboxes must be an integer!","Entry Error");
                textbox.Focus();
                return false;
            }//end if-else
            
        }//end IsInt64

        public bool IsValid()
        {
            return IsPresent(txtNumberOne) && IsPresent(txtNumberTwo) &&
                    IsInt32(txtNumberOne) && IsInt32(txtNumberTwo);
        }
    }//end Form1
}//end namespace
