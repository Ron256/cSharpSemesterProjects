﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingAssignmentThree
{
    public partial class Form1 : Form
    {
        private string[] iceCreamFlavors = { "Vanilla", "Chocolate", "Strawberry" };
        private string[] syrupFlavors = {"Chocolate", "Caramel","ButterScotch" };
        private string filePath = @Directory.GetCurrentDirectory() + "\\" + "images" + "\\";
        private string[] fileName = null;
        private List<string> fileNameList = new List<string>();
        private SortedList<string, string> revertedList = new SortedList<string, string>();
        
        public Form1()
        {
            InitializeComponent();
            FillComboBox(iceCreamFlavors, cboIceCreamFlavor);
            FillComboBox(syrupFlavors, cboSyrup);
            LoadImagesInList();
            cboIceCreamFlavor.SelectedIndex = 0;
            cboSyrup.SelectedIndex = 0;
        }// end Form1

        // This method uses the static method GetFiles of the Directory class to 
        // return a list of files to the array of string
        // Uses a for loop to process each file name image as it adds them to the memory 
        // using the List of Strings data structure
        private void LoadImagesInList()
        {
            string fileImagePath = filePath + "\\" +  "images" + "\\";
            fileName = Directory.GetFiles(filePath);
            for (int i = 0; i < fileName.Length; i++)
            {
                fileNameList.Add(fileName[i]);
            }   
            fileNameList.Sort();
        }// end LoadImagesInList
        
        // This method adds a string of iceCream flavor objects to the Combo box
        // It takes  a string array and a reference variable of ComboBox class as a parameters which are 
        // used by the for loop to process the string elements in the array as they 
        // are added to the Combobox 
        private void FillComboBox(String[] flavorsArray, ComboBox cboFlavor)
        {
            // Looping through an array of Strings iceCreamFlavors
            for (int counter = 0; counter < flavorsArray.Length; counter++)
            {
                cboFlavor.Items.Add(flavorsArray[counter]);
            }// end for loop
        }// end FillIceCreamComboBox

        // This event handler uses the selected Ice Cream flavor from the ComboBox drop down list
        // and using the ImageSearch method that takes selected Ice Cream Flavor as an argument,
        // it search for the Image Path of the ice Cream and displays in the Picture Box.
        private void IceCreamFlavorChanged(object sender, EventArgs e)
        {
            string iceCreamBrand = cboIceCreamFlavor.SelectedItem.ToString();
            if(iceCreamBrand == "Chocolate")
            { 
                ImageSearch("chocolate", picIceCreamFlavor);
            }
            else if (iceCreamBrand == "Strawberry")
            {
                ImageSearch("strawberry", picIceCreamFlavor);
            }
            else if (iceCreamBrand == "Vanilla")
            {
                ImageSearch("vanilla", picIceCreamFlavor);
            }// end if -else
        }// end IceCreamFlavorChanged

        // The ImageSearch Method is declared with two parameters which it uses to search for the corresponding image path
        // using a BinarySearch.
        // It uses this path for the Image to display in the PictureBox.
        private void ImageSearch(string iceCreamName, PictureBox picBoxName)
        {
            int counter = fileNameList.BinarySearch(filePath + iceCreamName + ".jpg");
            picBoxName.ImageLocation = fileNameList[counter];
        }// end ImageSearch

        // This event handler method validates if the user has selected selected an 
        // IceCream flavor from the IceCream drop down list
        // if the user has already selected an Ice Cream flavor and a type of Syrup 
        // from the ComboBox drop down lists using the ImageSearch method, 
        // it searches for the corresponding Image path for that selected Syrup 
        // passed as an argument to the ImageSearch method and displays it in the PictureBox.
        private void cboSyrup_SelectedIndexChanged(object sender, EventArgs e)
        {
            string syrupType = cboSyrup.SelectedItem.ToString();
            if (cboIceCreamFlavor.SelectedIndex == -1)
            {
                MessageBox.Show("User must select an IceCream brand from the IceCreamFlavor dropdownList","Input Error");
                cboIceCreamFlavor.Focus();
            }
            else
            {
                if (syrupType == "Chocolate")
                {
                    ImageSearch("chocolateSyrup", picSyrup);
                }
                else if (syrupType == "Caramel")
                {
                    ImageSearch("caramelSyrup", picSyrup);
                }
                else if (syrupType == "ButterScotch")
                {
                    ImageSearch("butterScotch", picSyrup);
                }
            }// end if-else
        }// end cboSyrup_SelectedIndexChanged

        // This method invokes the static methods of the IceCreamValidator class 
        // which validates if the user has selected any item from the IceCream 
        // and Syrup combobox drop downlists
        private bool ValidateUserInput()
        {
            return IceCreamValidator.ValidateSyrupCbo(cboSyrup) & 
                    IceCreamValidator.ValidateIcreamCbo(cboIceCreamFlavor);
        }// end ValidateUserInput

        // This event handler notifies the user if they haven't selected 
        // any IceCream flavor and type of Syrup from the respective drop down list.
        private void NutsCheckBoxClicked(object sender, EventArgs e)
        {
            this.ValidateUserInput();
        }// end  NutsCheckBoxClicked

        // This event handler notifies the user if they haven't selected 
        // any IceCream flavor and type of Syrup from the respective drop down list.
        private void CherriesCheckBoxClicked(object sender, EventArgs e)
        {
            this.ValidateUserInput();
        }//end CherriesCheckBoxClicked
        
        // This event handler notifies the user if they haven't selected 
        // any IceCream flavor and type of Syrup from the respective drop down list.
        private void SprinklesCheckBoxClicked(object sender, EventArgs e)
        {
            this.ValidateUserInput();
        }

        // This event handling method writes the IceCream brand, type of syrup 
        // and toppings selected for the customer to a file by using the SaveFileDialog  object 
        // which allows to specify a location to save the file to and 
        // it uses a StreamWriter class to write a stream of characters to a file.
        private void mnuFileSave_Click(object sender, EventArgs e)
        {
            // 
            FillRevertList();
            Stream fileStream = null;
            StreamWriter writerStream = null;
            //Create a SaveFileDialog object
            SaveFileDialog locateFileDialog = new SaveFileDialog();
            SaveFileDialog writeFileDialog = null;

            // Initialize the SaveFileDialog object members by passing the SaveFileDialog object
            // as an argument to the static method InitializeSaveFileDialog
            writeFileDialog = InitializeDialogParameters.InitializeSaveFileDialog(locateFileDialog);

            // call the dialog box by using ShowDialog method and save the current file.
            if (writeFileDialog.ShowDialog() == DialogResult.OK)
            {
                // open the file with read/write permission selected by the user
                // and set the value returned to the fileStream reference type of Stream class
                fileStream = locateFileDialog.OpenFile();

                // Pass the fileStream reference type to the StreamWriter construtor as an argument 
                // to create a StreamWriter object.
                writerStream = new StreamWriter(fileStream);

                if(cboIceCreamFlavor.SelectedIndex == -1)
                {
                    MessageBox.Show("User must selected an IceCream brand for the customer", "Input Error");
                }
               else if(cboSyrup.SelectedIndex == -1)
                {
                    MessageBox.Show("User must select a type of Syrup for the customer","Input Error");
                }
                else if (chkNuts.Checked == false && chkCherries.Checked == false && chkSprinkles.Checked == false)
                {
                    MessageBox.Show("User must select at least one topping before saving", "Input Error");
                }
                else
                {
                    writerStream.WriteLine(cboIceCreamFlavor.SelectedItem.ToString());
                    writerStream.WriteLine(cboSyrup.SelectedItem.ToString());
                    writerStream.WriteLine(ConvertBoolean(chkNuts.Checked));
                    writerStream.WriteLine(ConvertBoolean(chkCherries.Checked));
                    writerStream.WriteLine(ConvertBoolean(chkSprinkles.Checked));

                    FillRevertList();
                }// end if-else
                writerStream.Close();
                fileStream.Close();
            }//end if 
    }// end mnuFileSave_Click

        // This method takes a boolean parameter which it 
        // converts into string literals.
        private String ConvertBoolean(bool checkedStatus)
        {
            string checkedString = null;
            switch (checkedStatus)
            {
                case true:
                    checkedString = "Yes";
                    break;
                case false:
                    checkedString = "No";
                    break;
                default:
                    break;
            }
            return checkedString;
        }// end ConvertBoolean

        // This event handler closes the application.
        private void mnuOptionsClose_Click(object sender, EventArgs e)
        {
            this.Close();
        } // end mnuOptionsClose_Click

        // This event handling method Loads the iceCream data from a file to the Sorted List by using
        // the OpenFileDialog object to select an icorder file that gets loaded into a sorted List of Strings;
        // it uses a StreamReader class used to read a stream of characters from a file.
        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
           
            Stream fileStream = null;
            StreamReader readerStream = null;

            // create a OpenFileDialog object
            OpenFileDialog readFileDialog = new OpenFileDialog();
            OpenFileDialog initializedReadFileDialog = null;

            // Initializes the OpenFileDialog object members by passing the OpenFileDialog object as an argument 
            // to the static method InitializeOpenFileDialog
            initializedReadFileDialog = InitializeDialogParameters.InitializeOpenFileDialog(readFileDialog);

            // create a SortedList object and assign it to the 
            // reference variable of the SortedList class
            SortedList<string, string> iceCreamOrderList = new SortedList<string, string>();

            if (initializedReadFileDialog.ShowDialog() == DialogResult.OK)
            {
                // open the file with read/write permission selected by the user
                // and set the value returned to the fileStream reference type of Stream class
                fileStream = readFileDialog.OpenFile();

                // Pass the fileStream reference type to the StreamReader construtor as an argument 
                // to create a StreamReader object.
                readerStream = new StreamReader(fileStream);

                // Pass the StreamReader object as a parameter when calling the ProcessFileRead method
                // to read a file and adds the rows read into a sorted List of strings; 
                // this method returns the memory address of a sortedList
                // which is assigned to the reference variable ,iceCreamOrderList, of a
                // SortedList class type
                iceCreamOrderList = ProcessFileRead(readerStream);

                ProcessIceCreamOrderList(iceCreamOrderList);
                FillRevertList();
            }// end if

            // check if fileStream object is null
            if(fileStream != null)
            {
                fileStream.Close();
                readerStream.Close();
            } // end if
            
        } // end mnuFileOpen_Click

        // This method takes the iceCreamOrderList as a paramater 
        // which is used by the foreach loop to process the SortedList of string objects 
        // that causes the comboBox and picture boxes to load
        // the appropriate data, and images and also put a check mark on the respective checkboxes.
        private void ProcessIceCreamOrderList(SortedList<string, string> iceCreamOrderList)
        {
            foreach (KeyValuePair<string, string> iceCreamData in iceCreamOrderList)
            {
                if (iceCreamData.Key == "0")
                {
                    ProcessIceCreamOrderList(iceCreamData.Value);
                }
                else if (iceCreamData.Key == "1")
                {
                    ProcessIceCreamOrderSyrup(iceCreamData.Value);
                }
                else if (iceCreamData.Key == "2")
                {
                    if (iceCreamData.Value == "No")
                    {
                        chkNuts.Checked = false;
                    }
                    else
                        chkNuts.Checked = true;
                }
                else if (iceCreamData.Key == "3")
                {
                    if (iceCreamData.Value == "No")
                    {
                        chkCherries.Checked = false;
                    }
                    else
                        chkCherries.Checked = true;
                }
                else
                {
                    if (iceCreamData.Value == "No")
                    {
                        chkSprinkles.Checked = false;
                    }
                    else
                        chkSprinkles.Checked = true;
                }// end if-else

            }// end foreach
        }// end ProcessIceCreamOrderList

        // This method takes a string of an IceCream brand as a parameter
        // using a switch statement the IceCream Combo Box's text property 
        // is set to a correspoding IceCream flavor
        private void ProcessIceCreamOrderList(string iceCreamData)
        {
            switch(iceCreamData)
            {
                case "Vanilla":
                    cboIceCreamFlavor.Text = "Vanilla";
                    break;

                case "Chocolate":
                    cboIceCreamFlavor.Text = "Chocolate";
                    break;

                case "Strawberry":
                    cboIceCreamFlavor.Text = "Strawberry";
                    break;

                default:
                    Console.WriteLine("String passed for IceCream doesn't "+
                                      "exist: " + iceCreamData);
                    break;
            }
        }// end ProcessIceCreamOrderList

        // This method takes a string of an Syrup brand as a parameter
        // using a switch statement the IceCream Syrup Combo Box's text property 
        // is set to a correspoding Syrup
        private void ProcessIceCreamOrderSyrup(string iceCreamSyrup)
        {
            switch (iceCreamSyrup)
            {
                case "ButterScotch":
                    cboSyrup.Text = "ButterScotch";
                    break;

                case "Chocolate":
                    cboSyrup.Text = "Chocolate";
                    break;

                case "Caramel":
                    cboSyrup.Text = "Caramel";
                    break;

                default:
                    Console.WriteLine("String passed for Syrup doesn't " +
                                      "exist: " + iceCreamSyrup);
                    break;
            }// end switch
        }// end ProcessIceCreamOrderList

        // The ProcessFileRead method reads a file and adds the rows read into a list of strings
        // Pass a Stream reader object as a parameter whose value is to be processed
        // uses the Peek method in a while loop to return the next available character.
        // It returns a list of Strings once a stream of text characters have been read.
        private SortedList<string, string> ProcessFileRead(StreamReader readFileStream)
        {
            SortedList<string, string> orderList = new SortedList<string, string>();
            orderList.Clear();
            int counter = 0;
            while (readFileStream.Peek() != -1)
            {
                var orderRow = readFileStream.ReadLine();
                orderList.Add(counter.ToString(), orderRow);
                counter++;
            }
            return orderList;
        }//end processFileRead

        // This method uses the in memory reverted list  that is passed as an argument to the 
        // ProcessIceCreamOrderList method which loops through the sorted list object while
        // setting the combobox, picturebox and checkboxes to the objects to the object they had before.
        private void mnuOptionsRevert_Click(object sender, EventArgs e)
        {
            ProcessIceCreamOrderList(revertedList);
        }// end mnuOptionsRevert_Click

        // This method invokes the Additems method to add a string of objects 
        // to the Sorted List data structure.
        private void FillRevertList()
        {
            if(revertedList.Count == 0)
                AddItems();
            else
            {
                revertedList.Clear();
                AddItems();
            }
           
        }// end FillRevertList
     
        // The AddItems method adds a string of objects to the SortedList.
        private void AddItems()
        {
            revertedList.Add("0", cboIceCreamFlavor.SelectedItem.ToString());
            revertedList.Add("1", cboSyrup.SelectedItem.ToString());
            revertedList.Add("2", ConvertBoolean(chkNuts.Checked));
            revertedList.Add("3", ConvertBoolean(chkCherries.Checked));
            revertedList.Add("4", ConvertBoolean(chkSprinkles.Checked));
        }//end Additems

    }// end Form1
}// end ProgrammmingAssignmentsThree
