﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingAssignmentThree
{
    // InitializeDialogParameters is a static class with two static methods
    // whose purpose is to initialize the members of OpenFileDialog and SaveFileDialog objects.
    public static class InitializeDialogParameters
    {
        // The InitializeOpenFileDialog method Initializes the members of the OpenFileDialog object
        // It takes the object of the OpenFileDialog class as a parameter 
        // and returns the object of the OpenFileDialog.
        public static OpenFileDialog InitializeOpenFileDialog(OpenFileDialog readFileDialog)
        {
            readFileDialog.Filter = "iceCream order Files(*.icorder)|";
            readFileDialog.RestoreDirectory = true;
            readFileDialog.FileName = "*.icorder";
            readFileDialog.DefaultExt = "icorder";
            return readFileDialog;
        }//end InitializeOpenFileDialog

        // The InitializeSaveFileDialog method Initializes the members of the SaveFileDialog object
        // it takes the SaveFileDialog object as a parameter
        // and returns the object of the SaveFileDialog.
        public static SaveFileDialog InitializeSaveFileDialog(SaveFileDialog locateFileDialog)
        {
            locateFileDialog.Filter = "iceCream order Files(*.icorder)|";
            locateFileDialog.RestoreDirectory = true;
            locateFileDialog.FileName = "*.icorder";
            locateFileDialog.DefaultExt = "icorder";
            return locateFileDialog;
        }//end InitializeSaveFileDialo
    }//end class
}
