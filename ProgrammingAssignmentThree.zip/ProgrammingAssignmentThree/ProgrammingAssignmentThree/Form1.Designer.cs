﻿namespace ProgrammingAssignmentThree
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picSyrup = new System.Windows.Forms.PictureBox();
            this.mainMenu = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOptionsRevert = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOptionsClose = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cboIceCreamFlavor = new System.Windows.Forms.ComboBox();
            this.cboSyrup = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chkNuts = new System.Windows.Forms.CheckBox();
            this.chkCherries = new System.Windows.Forms.CheckBox();
            this.chkSprinkles = new System.Windows.Forms.CheckBox();
            this.picIceCreamFlavor = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picSyrup)).BeginInit();
            this.mainMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picIceCreamFlavor)).BeginInit();
            this.SuspendLayout();
            // 
            // picSyrup
            // 
            this.picSyrup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picSyrup.Location = new System.Drawing.Point(335, 122);
            this.picSyrup.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picSyrup.Name = "picSyrup";
            this.picSyrup.Size = new System.Drawing.Size(241, 401);
            this.picSyrup.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picSyrup.TabIndex = 10;
            this.picSyrup.TabStop = false;
            // 
            // mainMenu
            // 
            this.mainMenu.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.mainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.optionsToolStripMenuItem});
            this.mainMenu.Location = new System.Drawing.Point(0, 0);
            this.mainMenu.Name = "mainMenu";
            this.mainMenu.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.mainMenu.Size = new System.Drawing.Size(725, 28);
            this.mainMenu.TabIndex = 0;
            this.mainMenu.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFileOpen,
            this.mnuFileSave});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // mnuFileOpen
            // 
            this.mnuFileOpen.Name = "mnuFileOpen";
            this.mnuFileOpen.Size = new System.Drawing.Size(120, 26);
            this.mnuFileOpen.Text = "&Open";
            this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
            // 
            // mnuFileSave
            // 
            this.mnuFileSave.Name = "mnuFileSave";
            this.mnuFileSave.Size = new System.Drawing.Size(120, 26);
            this.mnuFileSave.Text = "&Save";
            this.mnuFileSave.Click += new System.EventHandler(this.mnuFileSave_Click);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuOptionsRevert,
            this.mnuOptionsClose});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(73, 24);
            this.optionsToolStripMenuItem.Text = "&Options";
            // 
            // mnuOptionsRevert
            // 
            this.mnuOptionsRevert.Name = "mnuOptionsRevert";
            this.mnuOptionsRevert.Size = new System.Drawing.Size(181, 26);
            this.mnuOptionsRevert.Text = "&Revert";
            this.mnuOptionsRevert.Click += new System.EventHandler(this.mnuOptionsRevert_Click);
            // 
            // mnuOptionsClose
            // 
            this.mnuOptionsClose.Name = "mnuOptionsClose";
            this.mnuOptionsClose.Size = new System.Drawing.Size(181, 26);
            this.mnuOptionsClose.Text = "&Close";
            this.mnuOptionsClose.Click += new System.EventHandler(this.mnuOptionsClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ice Cream Flavor:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(332, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Syrup:";
            // 
            // cboIceCreamFlavor
            // 
            this.cboIceCreamFlavor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboIceCreamFlavor.FormattingEnabled = true;
            this.cboIceCreamFlavor.Location = new System.Drawing.Point(14, 71);
            this.cboIceCreamFlavor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboIceCreamFlavor.Name = "cboIceCreamFlavor";
            this.cboIceCreamFlavor.Size = new System.Drawing.Size(230, 24);
            this.cboIceCreamFlavor.Sorted = true;
            this.cboIceCreamFlavor.TabIndex = 3;
            this.cboIceCreamFlavor.SelectedIndexChanged += new System.EventHandler(this.IceCreamFlavorChanged);
            // 
            // cboSyrup
            // 
            this.cboSyrup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboSyrup.FormattingEnabled = true;
            this.cboSyrup.Location = new System.Drawing.Point(335, 70);
            this.cboSyrup.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboSyrup.Name = "cboSyrup";
            this.cboSyrup.Size = new System.Drawing.Size(201, 24);
            this.cboSyrup.Sorted = true;
            this.cboSyrup.TabIndex = 4;
            this.cboSyrup.SelectedIndexChanged += new System.EventHandler(this.cboSyrup_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(591, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Toppings:";
            // 
            // chkNuts
            // 
            this.chkNuts.AutoSize = true;
            this.chkNuts.Location = new System.Drawing.Point(595, 74);
            this.chkNuts.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkNuts.Name = "chkNuts";
            this.chkNuts.Size = new System.Drawing.Size(59, 21);
            this.chkNuts.TabIndex = 6;
            this.chkNuts.Text = "Nuts";
            this.chkNuts.UseVisualStyleBackColor = true;
            this.chkNuts.Click += new System.EventHandler(this.NutsCheckBoxClicked);
            // 
            // chkCherries
            // 
            this.chkCherries.AutoSize = true;
            this.chkCherries.Location = new System.Drawing.Point(595, 140);
            this.chkCherries.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkCherries.Name = "chkCherries";
            this.chkCherries.Size = new System.Drawing.Size(83, 21);
            this.chkCherries.TabIndex = 7;
            this.chkCherries.Text = "Cherries";
            this.chkCherries.UseVisualStyleBackColor = true;
            this.chkCherries.Click += new System.EventHandler(this.CherriesCheckBoxClicked);
            // 
            // chkSprinkles
            // 
            this.chkSprinkles.AutoSize = true;
            this.chkSprinkles.Location = new System.Drawing.Point(595, 202);
            this.chkSprinkles.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkSprinkles.Name = "chkSprinkles";
            this.chkSprinkles.Size = new System.Drawing.Size(88, 21);
            this.chkSprinkles.TabIndex = 8;
            this.chkSprinkles.Text = "Sprinkles";
            this.chkSprinkles.UseVisualStyleBackColor = true;
            this.chkSprinkles.Click += new System.EventHandler(this.SprinklesCheckBoxClicked);
            // 
            // picIceCreamFlavor
            // 
            this.picIceCreamFlavor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picIceCreamFlavor.Location = new System.Drawing.Point(14, 122);
            this.picIceCreamFlavor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picIceCreamFlavor.Name = "picIceCreamFlavor";
            this.picIceCreamFlavor.Size = new System.Drawing.Size(230, 308);
            this.picIceCreamFlavor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picIceCreamFlavor.TabIndex = 9;
            this.picIceCreamFlavor.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(725, 531);
            this.Controls.Add(this.picSyrup);
            this.Controls.Add(this.picIceCreamFlavor);
            this.Controls.Add(this.chkSprinkles);
            this.Controls.Add(this.chkCherries);
            this.Controls.Add(this.chkNuts);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboSyrup);
            this.Controls.Add(this.cboIceCreamFlavor);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mainMenu);
            this.MainMenuStrip = this.mainMenu;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ice Cream Shop v 1.0";
            ((System.ComponentModel.ISupportInitialize)(this.picSyrup)).EndInit();
            this.mainMenu.ResumeLayout(false);
            this.mainMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picIceCreamFlavor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mainMenu;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuFileOpen;
        private System.Windows.Forms.ToolStripMenuItem mnuFileSave;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuOptionsRevert;
        private System.Windows.Forms.ToolStripMenuItem mnuOptionsClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboIceCreamFlavor;
        private System.Windows.Forms.ComboBox cboSyrup;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkNuts;
        private System.Windows.Forms.CheckBox chkCherries;
        private System.Windows.Forms.CheckBox chkSprinkles;
        private System.Windows.Forms.PictureBox picIceCreamFlavor;
        private System.Windows.Forms.PictureBox picSyrup;
    }
}

