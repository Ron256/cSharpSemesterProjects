﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingAssignmentThree
{
    // This is a static class with two static methods:
    public static class IceCreamValidator
    {
        // This method validates if the user has selected at least one IceCream flavor 
        // from the ComboBox dropdownlist.
        // It throws an error an if the user hasn't atleast selected an item.
        public static  bool ValidateIcreamCbo(ComboBox cboIceCreamTypes)
        {
            if (cboIceCreamTypes.SelectedIndex == -1)
            {
                MessageBox.Show("Atleast user must select one IceCream Flavor!", "Input Error");
                cboIceCreamTypes.Focus();
                return false;
            }// end if
            return true;
        }//end ValidateIcreamCbo

        // This method validates if the user has selected at least from Syrup flavor 
        // from the ComboBox dropdownlist.
        // It throws an error an if the user hasn't atleast selected an item.
        public static bool ValidateSyrupCbo(ComboBox cboSyrupTypes)
        {
            if (cboSyrupTypes.SelectedIndex == -1)
            {
                MessageBox.Show("Atleast user must select one Syrup type from the drop downlist", "Input Error");
                cboSyrupTypes.Focus();
                return false;
            }// end if
            return true;
        }// end ValidateSyrupCbo
    }
}
